package com.mycompany.app;

import org.orzhov.Excepciones.ConfigFormatoInvalidoException;
import org.orzhov.Main.App;
/**
 * Hello world!
 *
 */
public class Main {
    public static void main( String[] args )
    {
        try {
            App.main(args);
        } catch (ConfigFormatoInvalidoException ex) {
            System.out.println("El archivo introducido es ivnalido");
        }
    }
}
